let plantas = [];
let drone;
let chuva = false;
let umidadeSolo = 45; // Porcentagem inicial
let gotas = []; // Array para armazenar as gotas da irrigação

function setup() {
  // Cria o canvas descontando a largura da barra lateral (350px)
  let canvas = createCanvas(windowWidth - 350, windowHeight);
  canvas.parent('canvas-holder');
  
  // Inicializa o Drone no canto esquerdo da tela
  drone = {
    x: -50,
    y: 100,
    ativo: false,
    velocidade: 4
  };
  
  // Cria algumas plantas iniciais na fazenda
  for (let i = 0; i < 5; i++) {
    plantas.push({
      x: random(100, width - 100),
      y: random(height / 2 + 30, height - 80),
      tamanho: random(15, 30),
      cor: color(34, 139, 34)
    });
  }

  // Popula o array de gotas para a chuva
  for (let i = 0; i < 80; i++) {
    gotas.push({
      x: random(0, width),
      y: random(-height, 0),
      velocidade: random(4, 8)
    });
  }
}

function draw() {
  background(135, 206, 235); // Céu Azul

  // ---- CÉU E AMBIENTE ----
  // Sol Tecnológico
  fill(255, 223, 0);
  noStroke();
  ellipse(width - 80, 80, 80, 80);
  
  // Chão / Solo Agrícola
  fill(115, 82, 60); // Cor de terra nutrida
  rect(0, height / 2, width, height / 2);

  // ---- SISTEMA DE SENSORES ----
  desenharSensores();

  // ---- CUIDADO COM AS PLANTAS ----
  for (let p of plantas) {
    // Desenha o caule/raiz primeiro (atrás das folhas)
    fill(139, 69, 19);
    rect(p.x - 2, p.y, 4, 25); 

    // Desenha as folhas da planta
    fill(p.cor);
    ellipse(p.x, p.y, p.tamanho, p.tamanho * 1.4);

    // Se a irrigação inteligente estiver ligada, a planta cresce lentamente
    if (chuva && p.tamanho < 80) {
      p.tamanho += 0.04;
    }
  }

  // ---- INTERAÇÃO: DRONE AUTÔNOMO (Tecla D) ----
  if (drone.ativo) {
    atualizarEDesenharDrone();
  }

  // ---- INTERAÇÃO: IRRIGAÇÃO INTELIGENTE (Tecla C) ----
  if (chuva) {
    fazerChuva();
    if (umidadeSolo < 95) umidadeSolo += 0.15; // Aumenta umidade com a chuva
  } else {
    if (umidadeSolo > 20) umidadeSolo -= 0.02; // Solo secando naturalmente
  }
}

// Planta novas sementes ao clicar na terra (metade inferior do canvas)
function mousePressed() {
  if (mouseY > height / 2 && mouseX > 0) {
    plantas.push({
      x: mouseX,
      y: mouseY,
      tamanho: 12,
      cor: color(50, random(160, 255), 50) // Tons de verde tecnológico
    });
  }
}

// Escuta o teclado para ativar os comandos
function keyPressed() {
  if (key === 'd' || key === 'D') {
    drone.ativo = true;
    drone.x = -50; // Reseta a posição para cruzar a tela novamente
  }
  if (key === 'c' || key === 'C') {
    chuva = !chuva; // Liga/Desliga a irrigação
  }
}

// Função para simular sensores inteligentes de campo
function desenharSensores() {
  fill(0, 0, 0, 160);
  rect(20, 20, 280, 95, 10);
  
  fill(255);
  noStroke();
  textSize(13);
  text("📡 SENSORES DE CAMPO EM TEMPO REAL", 35, 45);
  
  textSize(12);
  text(`Umidade do Solo: {floor(umidadeSolo)}`, 35, 70);
  
  // Barra gráfica da umidade
  fill(50, 120, 255);
  rect(35, 80, umidadeSolo * 2.4, 10, 5);
}

// Desenha o Drone e faz o escaneamento a laser (Finalizado!)
function atualizarEDesenharDrone() {
  drone.x += drone.velocidade;

  // Linha laser de escaneamento agrícola
  stroke(0, 255, 0, 150);
  strokeWeight(2);
  line(drone.x, drone.y, drone.x, height / 2);
  noStroke();

  // Corpo do Drone
  fill(200);
  rect(drone.x - 25, drone.y - 8, 50, 16, 5);
  
  // Hélices (Esq / Dir)
  fill(50);
  ellipse(drone.x - 22, drone.y - 10, 20, 5); 
  ellipse(drone.x + 22, drone.y - 10, 20, 5); 
  
  // Câmera/Sensor óptico central do Drone
  fill(0, 255, 0);
  ellipse(drone.x, drone.y + 6, 10, 10);

  // Desativa o drone temporariamente ao sair da tela
  if (drone.x > width + 50) {
    drone.ativo = false;
  }
}

// Simulação física da chuva inteligente
function fazerChuva() {
  stroke(174, 219, 255, 200);
  strokeWeight(2);
  
  for (let g of gotas) {
    line(g.x, g.y, g.x, g.y + 12);
    g.y += g.velocidade;
    
    // Se a gota atingir o solo, reseta ela para o topo
    if (g.y > height) {
      g.y = random(-50, 0);
      g.x = random(0, width);
    }
  }
  noStroke();
}

// Ajusta o tamanho do canvas dinamicamente se o navegador mudar de tamanho
function windowResized() {
  resizeCanvas(windowWidth - 350, windowHeight);
}